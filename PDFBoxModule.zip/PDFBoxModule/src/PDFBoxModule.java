import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.tools.imageio.ImageIOUtil;

public class PDFBoxModule {
    public static void main(String[] args) throws Exception {
        // TODO Auto-generated method stub
    }
    public static int StaticAdd(int a, int b) {
        return a + b;
    }
    public int AddFunc(int a, int b) {
        return a + b;
    }
    public static boolean Initialize(String sourcePDFPath, String resultPath) {
        File filePath = new File(sourcePDFPath);
        if(filePath.exists() == false) {
            System.out.println("PDFBoxModule : pdf file not exist");
            return false;
        }
        try {
            Files.createDirectories(Paths.get(resultPath));
        } catch (IOException e) {
            System.out.println("PDFBoxModule : result folder create fail");
            return false;
        }
        return true;

    }
    public static boolean ConvertPDFToText(String sourcePDFPath, String resultTxtPath) {
        //System.out.println("PDFBOX-Module : convert pdf to text start");
        if(Initialize(sourcePDFPath, resultTxtPath) == false) {
            return false;
        }
        try {
            InputStream pdfInputStream = new FileInputStream(sourcePDFPath);
            PDDocument pdfDoc = PDDocument.load(pdfInputStream);
            String resultTxtFilePath = resultTxtPath + "/" + "result" + ".txt";
            //String resultText = stripper.getText((pdfDoc));

            OutputStream fileOutputStream = new FileOutputStream(new File(resultTxtFilePath));
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(fileOutputStream);
            BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);

            PDFTextStripper stripper = new PDFTextStripper();
            stripper.writeText(pdfDoc, bufferedWriter);

            pdfDoc.close();
            bufferedWriter.flush();
            bufferedWriter.close();
            outputStreamWriter.close();
            fileOutputStream.close();
            pdfInputStream.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }
    public static boolean ConvertPDFToImage(String sourcePDFPath, String resultImagePath, int dpi) {
        //System.out.println("PDFBOX-Module : convert pdf to image start");
        if(Initialize(sourcePDFPath, resultImagePath) == false) {
            return false;
        }
        try {
            InputStream pdfInputStream = new FileInputStream(sourcePDFPath);
            PDDocument pdfDoc = PDDocument.load(pdfInputStream);
            PDFRenderer pdfRenderer = new PDFRenderer(pdfDoc);

            for(int loop = 0; loop < pdfDoc.getPages().getCount(); loop++) {
                String imageFileName = resultImagePath + "/" + loop + ".png";
                BufferedImage bufferImage = pdfRenderer.renderImageWithDPI(loop, dpi, ImageType.RGB);
                ImageIOUtil.writeImage(bufferImage, imageFileName, dpi);
            }
            pdfDoc.close();
            pdfInputStream.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }
}
